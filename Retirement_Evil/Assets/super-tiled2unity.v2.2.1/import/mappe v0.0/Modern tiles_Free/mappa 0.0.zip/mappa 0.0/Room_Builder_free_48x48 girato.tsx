<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Room_Builder_free_48x48 girato" tilewidth="48" tileheight="48" tilecount="391" columns="23">
 <image source="Interiors_free/48x48/Room_Builder_free_48x48 girato.png" width="1104" height="816"/>
</tileset>
