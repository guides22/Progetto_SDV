<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Interiors_free_48x48" tilewidth="48" tileheight="48" tilecount="1424" columns="16">
 <image source="Interiors_free/48x48/Interiors_free_48x48.png" width="768" height="4272"/>
</tileset>
