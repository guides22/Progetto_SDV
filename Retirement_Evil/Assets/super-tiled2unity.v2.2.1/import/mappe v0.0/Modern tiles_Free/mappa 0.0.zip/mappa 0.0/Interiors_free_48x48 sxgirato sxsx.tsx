<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Interiors_free_48x48 sxgirato sxsx" tilewidth="48" tileheight="48" tilecount="1424" columns="89">
 <image source="Interiors_free/48x48/Interiors_free_48x48 sxgirato sxsx.png" width="4272" height="768"/>
</tileset>
